package com.studynotes.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notebooks")
data class Notebook(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "notes",
    foreignKeys = [ForeignKey(
        entity = Notebook::class,
        parentColumns = ["id"],
        childColumns = ["notebookId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("notebookId")]
)
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val notebookId: Long,
    val title: String,
    val body: String,
    val font: String = "Cursiva",
    val fontSize: Int = 20,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class StudyTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val completed: Boolean = false
)

@Dao
interface StudyDao {
    @Query("SELECT * FROM notebooks ORDER BY createdAt DESC")
    fun notebooks(): Flow<List<Notebook>>

    @Insert
    suspend fun addNotebook(notebook: Notebook): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreNotebooks(items: List<Notebook>)

    @Query("SELECT * FROM notes WHERE notebookId = :notebookId ORDER BY updatedAt DESC")
    fun notes(notebookId: Long): Flow<List<Note>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveNote(note: Note): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreNotes(items: List<Note>)

    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun allNotes(): Flow<List<Note>>

    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun tasks(): Flow<List<StudyTask>>

    @Insert
    suspend fun addTask(task: StudyTask)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreTasks(items: List<StudyTask>)

    @Query("DELETE FROM notes")
    suspend fun clearNotes()

    @Query("DELETE FROM tasks")
    suspend fun clearTasks()

    @Query("DELETE FROM notebooks")
    suspend fun clearNotebooks()

    @Update
    suspend fun updateTask(task: StudyTask)

    @Delete
    suspend fun deleteTask(task: StudyTask)
}

@Database(entities = [Notebook::class, Note::class, StudyTask::class], version = 1)
abstract class StudyDatabase : RoomDatabase() {
    abstract fun dao(): StudyDao
    companion object {
        @Volatile private var INSTANCE: StudyDatabase? = null
        fun get(context: Context): StudyDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StudyDatabase::class.java,
                    "studynotes.db"
                ).build().also { INSTANCE = it }
            }
    }
}
