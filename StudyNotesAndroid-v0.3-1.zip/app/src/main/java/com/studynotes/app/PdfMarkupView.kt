package com.studynotes.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.MotionEvent
import android.view.View
import java.io.OutputStream

/** PDF viewer with freehand annotations. Annotations are flattened into an exported PDF. */
class PdfMarkupView(context: Context) : View(context) {
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pageBitmap: Bitmap? = null
    private var pageIndex = 0
    private val annotations = mutableMapOf<Int, MutableList<List<Pair<Float, Float>>>>()
    private var activeStroke = mutableListOf<Pair<Float, Float>>()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val inkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(116, 83, 124)
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val pageRect = RectF()

    val pageCount: Int get() = renderer?.pageCount ?: 0
    val currentPage: Int get() = pageIndex + 1

    fun open(uri: Uri) {
        closeDocument()
        descriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Não foi possível abrir o PDF")
        renderer = PdfRenderer(descriptor!!)
        pageIndex = 0
        renderPage()
    }

    fun nextPage() {
        val r = renderer ?: return
        if (pageIndex < r.pageCount - 1) { pageIndex++; renderPage() }
    }

    fun previousPage() {
        if (pageIndex > 0) { pageIndex--; renderPage() }
    }

    fun clearCurrentPageAnnotations() {
        annotations.remove(pageIndex)
        activeStroke.clear()
        invalidate()
    }

    private fun renderPage() {
        val r = renderer ?: return
        val page = r.openPage(pageIndex)
        val bitmap = Bitmap.createBitmap(page.width.coerceAtLeast(1), page.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        pageBitmap?.recycle()
        pageBitmap = bitmap
        invalidate()
    }

    private fun calculatePageRect(bitmap: Bitmap): RectF {
        val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        return RectF((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(247, 242, 247))
        val bitmap = pageBitmap ?: return
        pageRect.set(calculatePageRect(bitmap))
        canvas.drawBitmap(bitmap, null, pageRect, bitmapPaint)
        val all = annotations[pageIndex].orEmpty() + listOf(activeStroke.toList())
        all.forEach { points ->
            if (points.size > 1) {
                val path = Path()
                points.forEachIndexed { index, p ->
                    val x = pageRect.left + p.first * pageRect.width()
                    val y = pageRect.top + p.second * pageRect.height()
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                canvas.drawPath(path, inkPaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (pageBitmap == null) return false
        val rect = calculatePageRect(pageBitmap!!)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!rect.contains(event.x, event.y)) return false
                activeStroke = mutableListOf(
                    ((event.x - rect.left) / rect.width()).coerceIn(0f, 1f) to
                    ((event.y - rect.top) / rect.height()).coerceIn(0f, 1f)
                )
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                activeStroke.add(
                    ((event.x - rect.left) / rect.width()).coerceIn(0f, 1f) to
                    ((event.y - rect.top) / rect.height()).coerceIn(0f, 1f)
                )
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                if (activeStroke.isNotEmpty()) annotations.getOrPut(pageIndex) { mutableListOf() }.add(activeStroke.toList())
                activeStroke.clear(); invalidate(); performClick(); return true
            }
            MotionEvent.ACTION_CANCEL -> { activeStroke.clear(); invalidate(); return true }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    fun exportAnnotatedPdf(output: OutputStream) {
        val r = renderer ?: throw IllegalStateException("Nenhum PDF aberto")
        val document = PdfDocument()
        try {
            for (index in 0 until r.pageCount) {
                val page = r.openPage(index)
                val bitmap = Bitmap.createBitmap(page.width.coerceAtLeast(1), page.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                page.close()
                val canvas = Canvas(bitmap)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(116, 83, 124); style = Paint.Style.STROKE
                    strokeWidth = 3.5f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                }
                annotations[index].orEmpty().forEach { points ->
                    if (points.size > 1) {
                        val path = Path()
                        points.forEachIndexed { i, p ->
                            val x = p.first * bitmap.width
                            val y = p.second * bitmap.height
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        canvas.drawPath(path, paint)
                    }
                }
                val info = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, index + 1).create()
                val outPage = document.startPage(info)
                outPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
                document.finishPage(outPage)
                bitmap.recycle()
            }
            document.writeTo(output)
        } finally {
            document.close()
        }
    }

    fun closeDocument() {
        pageBitmap?.recycle(); pageBitmap = null
        renderer?.close(); renderer = null
        descriptor?.close(); descriptor = null
        annotations.clear(); activeStroke.clear()
    }

    override fun onDetachedFromWindow() {
        closeDocument()
        super.onDetachedFromWindow()
    }
}
