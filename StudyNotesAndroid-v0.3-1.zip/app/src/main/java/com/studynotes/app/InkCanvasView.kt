package com.studynotes.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.view.MotionEvent
import android.view.View
import com.google.mlkit.vision.digitalink.recognition.Ink

class InkCanvasView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(112, 82, 119)
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val completedPaths = mutableListOf<AndroidPath>()
    private val completedStrokes = mutableListOf<Ink.Stroke>()
    private var activePath: AndroidPath? = null
    private var activeStroke: Ink.Stroke.Builder? = null
    private var activePoints = 0

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(android.graphics.Color.rgb(255, 252, 254))
        completedPaths.forEach { canvas.drawPath(it, paint) }
        activePath?.let { canvas.drawPath(it, paint) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        val time = event.eventTime
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePath = AndroidPath().apply { moveTo(x, y) }
                activeStroke = Ink.Stroke.builder().apply {
                    addPoint(Ink.Point.create(x, y, time))
                }
                activePoints = 1
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.historySize) {
                    val hx = event.getHistoricalX(i)
                    val hy = event.getHistoricalY(i)
                    val ht = event.getHistoricalEventTime(i)
                    activePath?.lineTo(hx, hy)
                    activeStroke?.addPoint(Ink.Point.create(hx, hy, ht))
                    activePoints++
                }
                activePath?.lineTo(x, y)
                activeStroke?.addPoint(Ink.Point.create(x, y, time))
                activePoints++
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                activePath?.lineTo(x, y)
                activeStroke?.addPoint(Ink.Point.create(x, y, time))
                activePath?.let { completedPaths.add(it) }
                if (activePoints > 0) activeStroke?.let { completedStrokes.add(it.build()) }
                activePath = null
                activeStroke = null
                invalidate()
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                activePath = null
                activeStroke = null
                invalidate()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun buildInk(): Ink {
        val builder = Ink.builder()
        completedStrokes.forEach { builder.addStroke(it) }
        return builder.build()
    }

    fun clearInk() {
        completedPaths.clear()
        completedStrokes.clear()
        activePath = null
        activeStroke = null
        invalidate()
    }

    fun hasInk(): Boolean = completedStrokes.isNotEmpty()
}
