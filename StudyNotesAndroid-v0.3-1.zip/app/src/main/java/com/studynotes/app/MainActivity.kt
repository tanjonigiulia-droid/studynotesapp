package com.studynotes.app

import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.graphics.Typeface
import java.io.File
import java.io.FileOutputStream
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import androidx.room.withTransaction
import com.studynotes.app.data.*
import kotlinx.coroutines.launch
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.recognition.Ink
import kotlinx.coroutines.flow.first

private val Pink = Color(0xFFF5E7F1)
private val Lilac = Color(0xFFECE8F8)
private val Ink = Color(0xFF725878)
private val Paper = Color(0xFFFFFCFE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyNotesApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyNotesApp() {
    val context = LocalContext.current
    val db = remember { StudyDatabase.get(context) }
    val dao = db.dao()
    val scope = rememberCoroutineScope()
    val notebooks by dao.notebooks().collectAsState(initial = emptyList())
    val tasks by dao.tasks().collectAsState(initial = emptyList())
    var tab by remember { mutableStateOf("Início") }
    var selectedNotebook by remember { mutableStateOf<Long?>(null) }
    val activeNotebookId = selectedNotebook ?: notebooks.firstOrNull()?.id ?: 0L
    val savedNotes by dao.notes(activeNotebookId).collectAsState(initial = emptyList())
    var noteTitle by remember { mutableStateOf("Minha anotação") }
    var noteBody by remember { mutableStateOf("") }
    var selectedFont by remember { mutableStateOf("Cursiva") }
    var fontSize by remember { mutableIntStateOf(20) }
    var status by remember { mutableStateOf("StudyNotes • seu espaço de estudos") }
    var taskText by remember { mutableStateOf("") }
    var pdfName by remember { mutableStateOf<String?>(null) }
    var selectedPdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfView by remember { mutableStateOf<PdfMarkupView?>(null) }
    var pdfPageLabel by remember { mutableStateOf("") }
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var inkCanvas by remember { mutableStateOf<InkCanvasView?>(null) }
    var recognizedText by remember { mutableStateOf("") }
    var recognitionStatus by remember { mutableStateOf("") }
    var importedFontName by remember { mutableStateOf(context.getSharedPreferences("studynotes", 0).getString("font_path", null)) }
    var importedTypeface by remember {
        mutableStateOf(importedFontName?.let { path ->
            try { Typeface.createFromFile(File(path)) } catch (_: Exception) { null }
        })
    }

    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val fontsDir = File(context.filesDir, "fonts").apply { mkdirs() }
                val target = File(fontsDir, "custom_${System.currentTimeMillis()}.font")
                context.contentResolver.openInputStream(it)?.use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
                importedTypeface = Typeface.createFromFile(target)
                importedFontName = target.absolutePath
                context.getSharedPreferences("studynotes", 0).edit().putString("font_path", target.absolutePath).apply()
                status = "Fonte personalizada importada"
            } catch (e: Exception) {
                status = "Não foi possível abrir essa fonte"
            }
        }
    }

    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let { destination ->
            scope.launch {
                try {
                    val notebookRows = dao.notebooks().first()
                    val noteRows = dao.allNotes().first()
                    val taskRows = dao.tasks().first()
                    val json = JSONObject()
                    json.put("format", "studynotes-backup-v1")
                    json.put("notebooks", JSONArray().apply {
                        notebookRows.forEach { put(JSONObject().put("id", it.id).put("name", it.name).put("createdAt", it.createdAt)) }
                    })
                    json.put("notes", JSONArray().apply {
                        noteRows.forEach { put(JSONObject().put("id", it.id).put("notebookId", it.notebookId).put("title", it.title).put("body", it.body).put("font", it.font).put("fontSize", it.fontSize).put("updatedAt", it.updatedAt)) }
                    })
                    json.put("tasks", JSONArray().apply {
                        taskRows.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("completed", it.completed)) }
                    })
                    context.contentResolver.openOutputStream(destination)?.bufferedWriter()?.use { it.write(json.toString(2)) }
                    status = "Backup exportado com sucesso"
                } catch (e: Exception) {
                    status = "Falha ao exportar backup"
                }
            }
        }
    }

    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        pendingRestoreUri = uri
    }

    val pdfExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { destination: Uri? ->
        destination?.let { uri ->
            scope.launch {
                try {
                    val view = pdfView ?: throw IllegalStateException("Abra um PDF primeiro")
                    context.contentResolver.openOutputStream(uri)?.use { output -> view.exportAnnotatedPdf(output) }
                        ?: throw IllegalStateException("Não foi possível criar o arquivo")
                    status = "PDF anotado exportado"
                } catch (e: Exception) {
                    status = "Falha ao exportar PDF: ${e.localizedMessage ?: "erro"}"
                }
            }
        }
    }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedPdfUri = it
            pdfName = it.lastPathSegment ?: "PDF selecionado"
            tab = "PDF"
            status = "PDF aberto: $pdfName"
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFFAA7FA8),
            secondary = Color(0xFF8E83B5),
            background = Color(0xFFFFFAFD),
            surface = Color(0xFFFFFAFD)
        )
    ) {
        if (pendingRestoreUri != null) {
            AlertDialog(
                onDismissRequest = { pendingRestoreUri = null },
                title = { Text("Restaurar backup?") },
                text = { Text("A restauração substituirá os cadernos, anotações e tarefas atuais deste aparelho. Exporte um backup antes se quiser guardar os dados atuais.") },
                confirmButton = {
                    TextButton(onClick = {
                        val source = pendingRestoreUri
                        pendingRestoreUri = null
                        if (source != null) scope.launch {
                            try {
                                restoreStudyBackup(context, db, dao, source)
                                selectedNotebook = dao.notebooks().first().firstOrNull()?.id
                                status = "Backup restaurado com sucesso"
                                tab = "Início"
                            } catch (e: Exception) {
                                status = "Falha ao restaurar: ${e.localizedMessage ?: "arquivo inválido"}"
                            }
                        }
                    }) { Text("Restaurar") }
                },
                dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
            )
        }
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("StudyNotes", color = Ink)
                            Text(status, style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = .7f))
                        }
                    },
                    actions = {
                        IconButton(onClick = { pdfPicker.launch(arrayOf("application/pdf")) }) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "Importar PDF")
                        }
                        IconButton(onClick = { backupPicker.launch("StudyNotes-backup.json") }) {
                            Icon(Icons.Default.Backup, contentDescription = "Exportar backup")
                        }
                        IconButton(onClick = { restorePicker.launch(arrayOf("application/json", "text/json", "application/octet-stream")) }) {
                            Icon(Icons.Default.Restore, contentDescription = "Restaurar backup")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Pink) {
                    listOf("Início", "Cadernos", "Editor", "PDF", "Fontes", "Planner").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Início" -> Icons.Default.Home
                                        "Cadernos" -> Icons.Default.MenuBook
                                        "Editor" -> Icons.Default.Edit
                                        "PDF" -> Icons.Default.PictureAsPdf
                                        "Fontes" -> Icons.Default.TextFields
                                        else -> Icons.Default.CalendarMonth
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().background(Color(0xFFFFFAFD))
                    .padding(padding).padding(16.dp)
            ) {
                when(tab) {
                    "Início" -> {
                        Text("Olá! Bem-vinda ♡", style = MaterialTheme.typography.headlineMedium, color = Ink)
                        Text("Seu cantinho de organização e criatividade.")
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("Cadernos", notebooks.size.toString(), Modifier.weight(1f))
                            StatCard("Tarefas", tasks.size.toString(), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { tab = "Cadernos" }, modifier = Modifier.fillMaxWidth()) {
                            Text("Abrir meus cadernos")
                        }
                        Button(onClick = { tab = "Editor" }, modifier = Modifier.fillMaxWidth()) {
                            Text("Nova anotação")
                        }
                        Text("Recursos: cadernos offline, editor, fontes, planner, PDFs anotáveis e backup/restauração JSON.")
                    }
                    "Cadernos" -> {
                        var name by remember { mutableStateOf("") }
                        Text("Meus cadernos", style = MaterialTheme.typography.headlineSmall, color = Ink)
                        OutlinedTextField(name, { name = it }, label = { Text("Nome do caderno") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                if(name.isNotBlank()) scope.launch {
                                    val id = dao.addNotebook(Notebook(name = name.trim()))
                                    selectedNotebook = id
                                    name = ""
                                    tab = "Editor"
                                }
                            }, modifier = Modifier.fillMaxWidth()
                        ) { Text("Criar caderno") }
                        LazyColumn {
                            items(notebooks) { notebook ->
                                ListItem(
                                    headlineContent = { Text(notebook.name) },
                                    leadingContent = { Icon(Icons.Default.MenuBook, null, tint = Ink) },
                                    modifier = Modifier.clickable {
                                        selectedNotebook = notebook.id
                                        tab = "Editor"
                                    }
                                )
                            }
                        }
                    }
                    "Editor" -> {
                        Text("Editor de anotações", style = MaterialTheme.typography.headlineSmall, color = Ink)
                        if(notebooks.isEmpty()) {
                            Text("Crie primeiro um caderno na aba Cadernos.")
                        } else {
                            var notebookId by remember { mutableLongStateOf(selectedNotebook ?: notebooks.first().id) }
                            LaunchedEffect(notebooks) {
                                if(notebooks.none { it.id == notebookId }) notebookId = notebooks.first().id
                            }
                            var drawingMode by remember { mutableStateOf(false) }
                            OutlinedTextField(noteTitle, { noteTitle = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth())
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Fonte")
                                Spacer(Modifier.width(8.dp))
                                FontDropdown(selectedFont) { selectedFont = it }
                            }
                            Slider(value = fontSize.toFloat(), onValueChange = { fontSize = it.toInt() }, valueRange = 12f..40f)
                            Text("Tamanho: $fontSize sp")
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Escrita livre")
                                Switch(checked = drawingMode, onCheckedChange = { drawingMode = it })
                            }
                            if(drawingMode) {
                                AndroidView(
                                    factory = { ctx -> InkCanvasView(ctx).also { inkCanvas = it } },
                                    modifier = Modifier.fillMaxWidth().height(250.dp)
                                        .border(1.dp, Color(0xFFD8C5D7), RoundedCornerShape(12.dp))
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { inkCanvas?.clearInk(); recognizedText = ""; recognitionStatus = "" }) {
                                        Text("Limpar")
                                    }
                                    Button(onClick = {
                                        val canvas = inkCanvas
                                        if (canvas == null || !canvas.hasInk()) {
                                            recognitionStatus = "Escreva algo na área antes de converter."
                                        } else {
                                            recognitionStatus = "Reconhecendo escrita..."
                                            HandwritingRecognition.recognizePortuguese(
                                                context, canvas.buildInk(),
                                                onResult = { result ->
                                                    recognizedText = result
                                                    recognitionStatus = "Texto reconhecido. Você pode revisar antes de inserir."
                                                },
                                                onError = { message -> recognitionStatus = message }
                                            )
                                        }
                                    }) { Text("Converter escrita") }
                                }
                                if (recognitionStatus.isNotBlank()) Text(recognitionStatus, color = Ink)
                                if (recognizedText.isNotBlank()) {
                                    OutlinedTextField(
                                        value = recognizedText,
                                        onValueChange = { recognizedText = it },
                                        label = { Text("Texto reconhecido (revise aqui)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Button(onClick = {
                                        noteBody = listOf(noteBody, recognizedText).filter { it.isNotBlank() }.joinToString("\\n")
                                        drawingMode = false
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Inserir no caderno") }
                                }
                                Text("A primeira conversão baixa o modelo pt-BR (cerca de 20 MB). Depois, o reconhecimento é feito no dispositivo.")
                            } else {
                                OutlinedTextField(
                                    noteBody, { noteBody = it },
                                    modifier = Modifier.fillMaxWidth().weight(1f),
                                    label = { Text("Escreva sua anotação") },
                                    textStyle = TextStyle(
                                        fontSize = fontSize.sp,
                                        fontFamily = importedTypeface?.let { FontFamily(it) } ?: FontFamily.Default
                                    )
                                )
                            }
                            Button(onClick = {
                                scope.launch {
                                    dao.saveNote(
                                        Note(
                                            notebookId = notebookId,
                                            title = noteTitle,
                                            body = noteBody,
                                            font = selectedFont,
                                            fontSize = fontSize
                                        )
                                    )
                                    status = "Anotação salva offline"
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Salvar anotação") }
                        }
                    }
                    "PDF" -> {
                        Text("Leitor e anotador de PDF", style = MaterialTheme.typography.headlineSmall, color = Ink)
                        if (selectedPdfUri == null) {
                            Text("Importe um PDF pelo ícone no topo da tela.")
                            Button(onClick = { pdfPicker.launch(arrayOf("application/pdf")) }) { Text("Importar PDF") }
                        } else {
                            Text(pdfName ?: "Documento PDF")
                            AndroidView(
                                factory = { ctx -> PdfMarkupView(ctx).also { view ->
                                    pdfView = view
                                    view.tag = selectedPdfUri
                                    try { view.open(selectedPdfUri!!) } catch (e: Exception) { status = "Erro ao abrir PDF: ${e.localizedMessage}" }
                                } },
                                update = { view ->
                                    pdfView = view
                                    if (view.tag != selectedPdfUri && selectedPdfUri != null) {
                                        view.tag = selectedPdfUri
                                        try { view.open(selectedPdfUri!!) } catch (e: Exception) { status = "Erro ao abrir PDF: ${e.localizedMessage}" }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(430.dp).border(1.dp, Color(0xFFD8C5D7), RoundedCornerShape(12.dp))
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(onClick = { pdfView?.previousPage(); pdfPageLabel = "Página ${pdfView?.currentPage ?: 1}/${pdfView?.pageCount ?: 0}" }) { Text("Anterior") }
                                Text(pdfPageLabel.ifBlank { "Página ${pdfView?.currentPage ?: 1}/${pdfView?.pageCount ?: 0}" }, modifier = Modifier.weight(1f))
                                OutlinedButton(onClick = { pdfView?.nextPage(); pdfPageLabel = "Página ${pdfView?.currentPage ?: 1}/${pdfView?.pageCount ?: 0}" }) { Text("Próxima") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { pdfView?.clearCurrentPageAnnotations() }, modifier = Modifier.weight(1f)) { Text("Limpar página") }
                                Button(onClick = { pdfExportPicker.launch("StudyNotes-anotado.pdf") }, modifier = Modifier.weight(1f)) { Text("Exportar PDF") }
                            }
                            Text("Desenhe com o dedo ou a S Pen sobre a página. As anotações são incorporadas ao PDF exportado.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    "Fontes" -> {
                        Text("Fontes & Lettering", style = MaterialTheme.typography.headlineSmall, color = Ink)
                        Text("Selecione uma família tipográfica para o editor.")
                        Button(onClick = { fontPicker.launch(arrayOf("font/ttf", "font/otf", "application/octet-stream")) }) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Text("Importar fonte .TTF ou .OTF")
                        }
                        importedFontName?.let { Text("Fonte personalizada: ${File(it).name}", color = Ink) }
                        listOf("Cursiva", "Lettering", "Manuscrita", "Minimalista", "Arredondada", "Máquina de escrever", "Clássica", "Brush lettering").forEach { font ->
                            ElevatedCard(
                                onClick = { selectedFont = font; tab = "Editor" },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                colors = CardDefaults.elevatedCardColors(containerColor = Lilac)
                            ) {
                                Text(
                                    "${font}     StudyNotes ♡",
                                    modifier = Modifier.padding(14.dp),
                                    color = Ink,
                                    style = TextStyle(fontFamily = fontFamilyFor(font), fontSize = 19.sp)
                                )
                            }
                        }
                        Text("A fonte importada é aplicada ao texto digitado no editor. As categorias ilustrativas ainda usam as fontes padrão do sistema até receberem arquivos tipográficos próprios.")
                    }
                    "Planner" -> {
                        Text("Planner de estudos", style = MaterialTheme.typography.headlineSmall, color = Ink)
                        OutlinedTextField(taskText, { taskText = it }, label = { Text("Nova tarefa") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if(taskText.isNotBlank()) scope.launch {
                                dao.addTask(StudyTask(title = taskText.trim()))
                                taskText = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Adicionar tarefa") }
                        LazyColumn {
                            items(tasks) { task ->
                                ListItem(
                                    headlineContent = { Text(task.title) },
                                    leadingContent = {
                                        Checkbox(task.completed, { checked ->
                                            scope.launch { dao.updateTask(task.copy(completed = checked)) }
                                        })
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun restoreStudyBackup(
    context: Context,
    db: StudyDatabase,
    dao: StudyDao,
    source: Uri
) {
    val raw = context.contentResolver.openInputStream(source)?.bufferedReader()?.use { it.readText() }
        ?: throw IllegalStateException("Arquivo vazio")
    val json = JSONObject(raw)
    require(json.optString("format") == "studynotes-backup-v1") { "Formato de backup não reconhecido" }
    val notebookArray = json.optJSONArray("notebooks") ?: JSONArray()
    val noteArray = json.optJSONArray("notes") ?: JSONArray()
    val taskArray = json.optJSONArray("tasks") ?: JSONArray()
    val restoredNotebooks = (0 until notebookArray.length()).map { i ->
        val item = notebookArray.getJSONObject(i)
        Notebook(id = item.getLong("id"), name = item.getString("name"), createdAt = item.optLong("createdAt", System.currentTimeMillis()))
    }
    val restoredNotes = (0 until noteArray.length()).map { i ->
        val item = noteArray.getJSONObject(i)
        Note(id = item.getLong("id"), notebookId = item.getLong("notebookId"), title = item.getString("title"), body = item.optString("body"), font = item.optString("font", "Cursiva"), fontSize = item.optInt("fontSize", 20), updatedAt = item.optLong("updatedAt", System.currentTimeMillis()))
    }
    val restoredTasks = (0 until taskArray.length()).map { i ->
        val item = taskArray.getJSONObject(i)
        StudyTask(id = item.getLong("id"), title = item.getString("title"), completed = item.optBoolean("completed", false))
    }
    db.withTransaction {
        dao.clearNotes()
        dao.clearTasks()
        dao.clearNotebooks()
        if (restoredNotebooks.isNotEmpty()) dao.restoreNotebooks(restoredNotebooks)
        if (restoredNotes.isNotEmpty()) dao.restoreNotes(restoredNotes)
        if (restoredTasks.isNotEmpty()) dao.restoreTasks(restoredTasks)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, colors = CardDefaults.elevatedCardColors(containerColor = Pink)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Ink)
            Text(label, color = Ink)
        }
    }
}

@Composable
fun FontDropdown(selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text(selected) }
        DropdownMenu(expanded, { expanded = false }) {
            listOf("Cursiva", "Lettering", "Manuscrita", "Minimalista", "Arredondada", "Máquina de escrever", "Clássica", "Brush lettering").forEach {
                DropdownMenuItem(text = { Text(it) }, onClick = { onSelected(it); expanded = false })
            }
        }
    }
}

private fun fontFamilyFor(name: String): FontFamily = when (name) {
    "Cursiva", "Manuscrita", "Brush lettering" -> FontFamily.Cursive
    "Máquina de escrever" -> FontFamily.Monospace
    "Clássica" -> FontFamily.Serif
    "Arredondada", "Minimalista", "Lettering" -> FontFamily.SansSerif
    else -> FontFamily.Default
}

@Composable
fun HandwritingPad(
    modifier: Modifier = Modifier,
    onRecognize: (List<List<Offset>>) -> Unit
) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf(listOf<Offset>()) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Canvas(
            modifier.background(Paper).border(1.dp, Color(0xFFD8C5D7), RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { current = listOf(it) },
                        onDrag = { change, _ ->
                            current = current + change.position
                            change.consume()
                        },
                        onDragEnd = {
                            if (current.isNotEmpty()) strokes.add(current)
                            current = emptyList()
                        }
                    )
                }
        ) {
            (strokes + listOf(current)).forEach { points ->
                if (points.size > 1) {
                    val path = Path().apply {
                        moveTo(points.first().x, points.first().y)
                        points.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    drawPath(path, Color(0xFF765879), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f, cap = StrokeCap.Round))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) }, modifier = Modifier.weight(1f)) { Text("Desfazer") }
            OutlinedButton(onClick = { strokes.clear(); current = emptyList() }, modifier = Modifier.weight(1f)) { Text("Limpar") }
            Button(onClick = { if (strokes.isNotEmpty()) onRecognize(strokes.toList()) }, modifier = Modifier.weight(1f)) { Text("Converter") }
        }
    }
}

private fun recognizePortugueseInk(
    context: android.content.Context,
    strokes: List<List<Offset>>,
    onSuccess: (String) -> Unit,
    onFailure: (String) -> Unit
) {
    try {
        val identifier = DigitalInkRecognitionModelIdentifier.fromLanguageTag("pt-BR")
        if (identifier == null) {
            onFailure("O modelo pt-BR não está disponível nesta versão do ML Kit.")
            return
        }
        val model = DigitalInkRecognitionModel.builder(identifier).build()
        RemoteModelManager.getInstance()
            .download(model, DownloadConditions.Builder().build())
            .addOnSuccessListener {
                val inkBuilder = Ink.builder()
                var timestamp = 0L
                strokes.forEach { points ->
                    if (points.isNotEmpty()) {
                        val strokeBuilder = Ink.Stroke.builder()
                        points.forEach { point ->
                            timestamp += 12L
                            strokeBuilder.addPoint(Ink.Point.create(point.x, point.y, timestamp))
                        }
                        inkBuilder.addStroke(strokeBuilder.build())
                    }
                }
                val recognizer = DigitalInkRecognition.getClient(
                    DigitalInkRecognizerOptions.builder(model).build()
                )
                recognizer.recognize(inkBuilder.build())
                    .addOnSuccessListener { result ->
                        val recognized = result.candidates.firstOrNull()?.text.orEmpty()
                        recognizer.close()
                        if (recognized.isBlank()) onFailure("Não consegui reconhecer. Tente escrever maior e com mais espaço.")
                        else onSuccess(recognized)
                    }
                    .addOnFailureListener { error ->
                        recognizer.close()
                        onFailure("Falha no reconhecimento: ${error.localizedMessage ?: "tente novamente"}")
                    }
            }
            .addOnFailureListener { error ->
                onFailure("Não foi possível baixar o modelo de português. Verifique a conexão. ${error.localizedMessage ?: ""}")
            }
    } catch (error: Exception) {
        onFailure("Erro ao iniciar o reconhecimento: ${error.localizedMessage ?: "desconhecido"}")
    }
}
