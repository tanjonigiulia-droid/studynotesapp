package com.studynotes.app

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.recognition.*

object HandwritingRecognition {
    fun recognizePortuguese(
        context: Context,
        ink: Ink,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val identifier = DigitalInkRecognitionModelIdentifier.fromLanguageTag("pt-BR")
            if (identifier == null) {
                onError("Não foi encontrado um modelo de reconhecimento para português do Brasil.")
                return
            }
            val model = DigitalInkRecognitionModel.builder(identifier).build()
            val manager = RemoteModelManager.getInstance()

            fun runRecognition() {
                val recognizer = DigitalInkRecognition.getClient(
                    DigitalInkRecognizerOptions.builder(model).build()
                )
                recognizer.recognize(ink)
                    .addOnSuccessListener { result ->
                        val text = result.candidates.firstOrNull()?.text
                        if (text.isNullOrBlank()) onError("Não consegui reconhecer essa escrita. Tente escrever uma frase mais curta.")
                        else onResult(text)
                        recognizer.close()
                    }
                    .addOnFailureListener { error ->
                        onError(error.localizedMessage ?: "Falha no reconhecimento.")
                        recognizer.close()
                    }
            }

            manager.isModelDownloaded(model)
                .addOnSuccessListener { downloaded ->
                    if (downloaded) {
                        runRecognition()
                    } else {
                        onError("Baixando o modelo de português (aprox. 20 MB). Aguarde e tente novamente.")
                        manager.download(model, DownloadConditions.Builder().build())
                            .addOnSuccessListener { runRecognition() }
                            .addOnFailureListener { e ->
                                onError(e.localizedMessage ?: "Não foi possível baixar o modelo de idioma.")
                            }
                    }
                }
                .addOnFailureListener { e ->
                    onError(e.localizedMessage ?: "Não foi possível verificar o modelo.")
                }
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "Erro ao iniciar reconhecimento.")
        }
    }
}
