# StudyNotes Android — versão 0.3

Aplicativo Android nativo em Kotlin + Jetpack Compose, com identidade pastel e armazenamento local.

## Abrir o projeto
1. Instale o Android Studio recente (Android Gradle Plugin 8.7.3 / Gradle 8.9; JDK 17).
2. Abra a pasta `StudyNotesAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação das dependências.
4. Execute em um emulador ou dispositivo Android (API 26+).

## Recursos incluídos no código
- Interface pastel e navegação por Início, Cadernos, Editor, PDF, Fontes e Planner.
- Cadernos, anotações e tarefas salvos localmente com Room.
- Editor de texto com tamanho de letra e seleção de família tipográfica.
- Importação de fontes TTF/OTF; a fonte importada é guardada no armazenamento privado e a seleção é lembrada.
- Área de escrita livre compatível com eventos de toque/caneta e reconhecimento manuscrito pt-BR via ML Kit Digital Ink Recognition.
- Revisão do texto reconhecido antes de inserir no editor.
- Importação de PDF pelo seletor Android, visualização página a página, escrita livre sobre a página e exportação de um novo PDF com as anotações incorporadas (rasterizadas/achatadas).
- Exportação e restauração de backup JSON de cadernos, notas e tarefas.
- Regras de Android Auto Backup para incluir banco de dados, arquivos e preferências quando o backup do dispositivo/conta Google estiver habilitado.
- Compartilhamento/backup JSON pelo seletor Android: o usuário pode escolher um provedor de nuvem instalado, como Google Drive, para guardar o arquivo manualmente.

## Observações importantes
- Este é um projeto-fonte Android, não um APK compilado. O ambiente em que foi montado não possui Android SDK/Gradle configurado; portanto, não foi possível executar uma compilação ou testar em hardware real aqui.
- O primeiro uso do reconhecimento manuscrito precisa baixar o modelo de idioma pt-BR. Depois do download, o reconhecimento é executado no dispositivo. O reconhecimento depende da qualidade dos traços e pode exigir revisão manual.
- A anotação de PDF é exportada como conteúdo achatado sobre cada página. O texto original do PDF não é editado; as anotações não ficam como camadas separadas editáveis.
- A área de desenho e a anotação em PDF aceitam entrada de stylus/toque, mas ainda não implementam pressão, inclinação, borracha inteligente, seleção por laço ou otimizações específicas da S Pen.
- O backup automático depende das configurações de backup do Android/Google e das políticas do dispositivo. O backup via Google Drive/OneDrive pelo seletor é manual. Sincronização contínua entre dispositivos exigiria um backend, autenticação, regras de conflito e configuração de serviço de nuvem; isso não está incluído.
- As categorias tipográficas são famílias de sistema de demonstração. Para lettering visualmente fiel, adicione arquivos TTF/OTF licenciados. A fonte importada é aplicada ao texto digitado; a escrita manuscrita original não é redesenhada como lettering.

## Identidade
StudyNotes é um projeto original inspirado em aplicativos de caderno digital; não usa a marca nem o código do FreeNotes.
